$("#modalImageSmall").hover(function(){
    $(this).find(".centered").toggle();
});