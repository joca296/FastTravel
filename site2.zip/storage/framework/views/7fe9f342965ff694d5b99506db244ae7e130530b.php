<?php /* C:\xampp\htdocs\site2\resources\views/pages/admin/offers.blade.php */ ?>
<?php $__env->startSection('title','Admin - Offer List'); ?>

<?php $__env->startSection('content'); ?>
    <h1>Offers</h1>
    <div class="table-responsive-sm">
        <table class="table table-striped table-sm">
            <thead class="thead-dark">
            <th>#</th>
            <th>Location</th>
            <th>Country</th>
            <th>Season</th>
            <th>Price</th>
            <th>Description</th>
            <th class="text-center">Action</th>
            </thead>
            <tbody>
            <?php $__currentLoopData = $offers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $offer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th scope="row" class="idOffer"><?php echo e($offer->idOffer); ?></th>
                    <td><?php echo e($offer->location->locationName); ?></td>
                    <td><?php echo e($offer->country->countryName); ?></td>
                    <td><?php echo e($offer->season->seasonName); ?></td>
                    <td>$<?php echo e($offer->price); ?></td>
                    <td class="text-truncate" style="max-width: 250px"><?php echo e($offer->description); ?></td>
                    <td class="text-center" style="max-width: 80px">
                        <a href="<?php echo e(url('/')); ?>/offers/edit/<?php echo e($offer->idOffer); ?>" class="btn btn-outline-primary">Update</a>
                        <a href="<?php echo e(url('/')); ?>/offers/delete/<?php echo e($offer->idOffer); ?>" class="btn btn-outline-danger">Delete</a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>