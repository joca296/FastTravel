<?php /* C:\xampp\htdocs\site2\resources\views/pages/admin/edit/location.blade.php */ ?>
<?php $__env->startSection('title','Admin - Edit Location'); ?>

<?php $__env->startSection('content'); ?>
    <h1>Edit location:</h1>
    <form action="<?php echo e(url('/')); ?>/locations/edit/<?php echo e($location->idLocation); ?>" method="post">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for="country">Country:</label>
            <select class="custom-select" name="country">
                <option value="">Select...</option>
                <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($country->idCountry); ?>" <?php echo e($location->idCountry == $country->idCountry ? 'selected' : ''); ?>><?php echo e($country->countryName); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="form-group">
            <label for="location">Location:</label>
            <input type="text" name="location" id="tbLocation" class="form-control" value="<?php echo e($location->locationName); ?>">
        </div>
        <div class="form-group">
            <button type="submit" class="btn btn-primary" name="btnUpdate">Update</button>
            <button type="reset" class="btn btn-danger" name="btnReset">Reset</button>
        </div>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>