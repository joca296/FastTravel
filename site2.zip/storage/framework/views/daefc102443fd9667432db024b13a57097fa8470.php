<?php /* C:\xampp\htdocs\site2\resources\views/include/nav.blade.php */ ?>
<nav class="navbar sticky-top navbar-expand-lg navbar-dark bg-dark">
    <a class="navbar-brand" href="<?php echo e(url('/')); ?>/">Fast Travel</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav mr-auto">
            <?php $__currentLoopData = $menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menuItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="nav-item">
                    <a class="nav-link <?php echo e(Request::path() == substr($menuItem->link,1) ? 'active': ''); ?>" href="<?php echo e(url('/').$menuItem->link); ?>"><?php echo e($menuItem->menuName); ?></a>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php if(Auth::check()): ?>
                <li class="nav-item dropdown <?php echo e(strstr(Request::path(),'user')? 'active' : ''); ?>">
                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">User Tools</a>
                    <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                        <?php $__currentLoopData = $userLinks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $userLink): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a class="dropdown-item" href="<?php echo e(url('/').$userLink->link); ?>"><?php echo e($userLink->menuName); ?></a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </li>
                <?php if(Auth::user()->admin == 1): ?>
                    <li class="nav-item">
                        <a class="nav-link <?php echo e(strstr(Request::path(),'admin')? 'active' : ''); ?>" href="<?php echo e(url('/')); ?>/admin">Admin Panel</a>
                    </li>
                <?php endif; ?>
            <?php endif; ?>
        </ul>
    </div>
    <?php echo $__env->make('include.login', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</nav>