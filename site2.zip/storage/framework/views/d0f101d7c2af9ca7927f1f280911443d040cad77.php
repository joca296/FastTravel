<?php /* C:\xampp\htdocs\site2\resources\views/pages/admin/locations.blade.php */ ?>
<?php $__env->startSection('title','Admin - Location List'); ?>

<?php $__env->startSection('content'); ?>
    <h1>Locations</h1>
    <div class="table-responsive-sm">
        <table class="table table-striped table-sm">
            <thead class="thead-dark">
            <th>#</th>
            <th>Country</th>
            <th>Name</th>
            <th class="text-center">Action</th>
            </thead>
            <tbody>
            <?php $__currentLoopData = $locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $location): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th scope="row" class="idOffer"><?php echo e($location->idLocation); ?></th>
                    <td><?php echo e($location->country->countryName); ?></td>
                    <td><?php echo e($location->locationName); ?></td>
                    <td class="text-center" style="max-width: 80px">
                        <a href="<?php echo e(url('/')); ?>/locations/edit/<?php echo e($location->idLocation); ?>" class="btn btn-outline-primary">Update</a>
                        <a href="<?php echo e(url('/')); ?>/locations/delete/<?php echo e($location->idLocation); ?>" class="btn btn-outline-danger">Delete</a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>