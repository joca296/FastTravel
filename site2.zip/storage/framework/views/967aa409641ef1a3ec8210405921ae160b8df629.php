<?php /* C:\xampp\htdocs\site2\resources\views/include/adminNav.blade.php */ ?>
<nav class="col-2 bg-white sidebar">
    <div class="sidebar-sticky">
        <h6 class="sidebar-heading d-flex justify-content-between align-items-center px-3 mt-4 mb-1 text-muted">
            <span>List All</span>
        </h6>
        <ul class="nav flex-column">
            <?php $__currentLoopData = $listLinks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $listLink): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="nav-item">
                    <a class="nav-link <?php echo e(Request::path() == substr($listLink->link,1) ? 'active': ''); ?>" href="<?php echo e(url('/').$listLink->link); ?>"><?php echo e($listLink->menuName); ?></a>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
        <h6 class="sidebar-heading d-flex justify-content-between align-items-center px-3 mt-4 mb-1 text-muted">
            <span>Insert</span>
        </h6>
        <ul class="nav flex-column">
            <?php $__currentLoopData = $insertLinks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $insertLink): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="nav-item">
                    <a class="nav-link <?php echo e(Request::path() == substr($insertLink->link,1) ? 'active': ''); ?>" href="<?php echo e(url('/').$insertLink->link); ?>"><?php echo e($insertLink->menuName); ?></a>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
</nav>