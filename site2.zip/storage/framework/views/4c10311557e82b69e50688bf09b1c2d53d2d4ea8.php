<?php /* C:\xampp\htdocs\site2\resources\views/pages/admin/insert/offer.blade.php */ ?>
<?php $__env->startSection('title','Admin - Insert Offer'); ?>

<?php $__env->startSection('content'); ?>
    <h1>Insert offer</h1>
    <form action="<?php echo e(url('/')); ?>/admin/insert/offer" method="post" enctype="multipart/form-data">
        <div class="form-group">
            <?php echo csrf_field(); ?>
            <label for="country">Country:</label>
            <select class="custom-select" name="country" id="sCountry">
                <option value="">Country...</option>
                <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($country->idCountry); ?>"><?php echo e($country->countryName); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="form-group">
            <label for="location">Location:</label>
            <select class="custom-select mr-2" name="location" id="sLocation">
                <option value="">Location...</option>
            </select>
        </div>
        <div class="form-group">
            <label for="season">Season:</label>
            <select class="custom-select" name="season" id="sSeason">
                <option value="">Season...</option>
                <?php $__currentLoopData = $seasons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $season): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($season->idSeason); ?>"><?php echo e($season->seasonName); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="form-group">
            <label for="price">Price:</label>
            <input type="number" name="price" id="tbPrice" class="form-control">
        </div>
        <div class="form-group">
            <label for="description">Description:</label>
            <textarea name="description" id="taDescription" class="form-control"></textarea>
        </div>
        <div class="form-group">
            <label for="picture">Image:</label>
            <input type="file" name="picture" id="fPicture" class="form-control-file">
            <span class="font-italic">Picture must be in 16:9 aspect ratio.</span>
        </div>
        <div class="form-group">
            <label for="pictureAlt">Image Alt:</label>
            <input type="text" name="pictureAlt" id="tbPictureAlt" class="form-control">
        </div>
        <div class="form-group">
            <button type="submit" class="btn btn-primary" name="btnInsertOffer">Insert</button>
            <button type="reset" class="btn btn-danger" name="btnReset">Reset</button>
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(url('/')); ?>/js/locationFilter.js"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>