<?php /* C:\xampp\htdocs\site2\resources\views/include/footer.blade.php */ ?>
</body>
</html>