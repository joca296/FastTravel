<?php /* C:\xampp\htdocs\site2\resources\views/pages/admin/edit/offer.blade.php */ ?>
<?php $__env->startSection('title','Admin - Edit Offer'); ?>

<?php $__env->startSection('content'); ?>
    <h1>Edit offer</h1>
    <form action="<?php echo e(url('/')); ?>/offers/edit/<?php echo e($offer->idOffer); ?>" method="post" enctype="multipart/form-data">
        <div class="form-group">
            <?php echo csrf_field(); ?>
            <label for="country">Country:</label>
            <select class="custom-select" name="country" id="sCountry">
                <option value="">Country...</option>
                <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($country->idCountry); ?>" <?php echo e($offer->country->idCountry == $country->idCountry ? 'selected' : ''); ?>><?php echo e($country->countryName); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="form-group">
            <label for="location">Location:</label>
            <select class="custom-select mr-2" name="location" id="sLocation">
                <option value="">Location...</option>
                <?php $__currentLoopData = $locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $location): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($location->idLocation); ?>" <?php echo e($offer->location->idLocation == $location->idLocation ? 'selected' : ''); ?>><?php echo e($location->locationName); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="form-group">
            <label for="season">Season:</label>
            <select class="custom-select" name="season" id="sSeason">
                <option value="">Season...</option>
                <?php $__currentLoopData = $seasons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $season): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($season->idSeason); ?>" <?php echo e($offer->season->idSeason == $season->idSeason ? 'selected' : ''); ?>><?php echo e($season->seasonName); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="form-group">
            <label for="price">Price:</label>
            <input type="number" name="price" id="tbPrice" class="form-control" value="<?php echo e($offer->price); ?>">
        </div>
        <div class="form-group">
            <label for="description">Description:</label>
            <textarea name="description" id="taDescription" class="form-control"><?php echo e($offer->description); ?></textarea>
        </div>
        <div class="form-group">
            <label for="picture">Image:</label>
            <input type="file" name="picture" id="fPicture" class="form-control-file">
            <span class="font-italic">Picture must be in 16:9 aspect ratio.</span>
        </div>
        <div class="form-group">
            <label for="pictureAlt">Image Alt:</label>
            <input type="text" name="pictureAlt" id="tbPictureAlt" class="form-control" value="<?php echo e($offer->picture->alt); ?>">
        </div>
        <div class="form-group">
            <button type="submit" class="btn btn-primary" name="btnUpdate">Update</button>
            <button type="reset" class="btn btn-danger" name="btnReset">Reset</button>
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(url('/')); ?>/js/locationFilter.js"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>