<?php /* C:\xampp\htdocs\site2\resources\views/pages/survey.blade.php */ ?>
<?php $__env->startSection('title','Survey'); ?>
<?php $__env->startSection('content'); ?>
    <div class="row content" id="surveyDiv">
        <div class="col-invisible col-lg-3"></div>
        <div class="col-12 col-lg-6">
            <form action="<?php echo e(url('/')); ?>/survey" method="post" id="survey">
                <?php echo csrf_field(); ?>
                <?php $__currentLoopData = $survey; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="form-group">
                        <label for="question<?php echo e($question->first()->question->idQuestion); ?>"><?php echo e($question->first()->question->question); ?></label>
                        <select class="custom-select mr-2" name="question<?php echo e($question->first()->question->idQuestion); ?>" id="question<?php echo e($question->first()->question->idQuestion); ?>">
                            <option value="">Select...</option>
                            <?php $__currentLoopData = $question; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $answer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($answer->idAnswer); ?>"><?php echo e($answer->answer); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <div class="form-group">
                    <label for="taComment">Comment: (optional)</label>
                    <textarea class="form-control" id="comment" name="comment"></textarea>
                </div>
                <div class="form-group">
                    <button type="submit" class="btn btn-primary" name="btnSubmitSurvey">Submit</button>
                    <button type="reset" class="btn btn-danger" name="btnReset">Reset</button>
                </div>
            </form>
        </div>
        <div class="col-invisible col-lg-3"></div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(url('/')); ?>/js/submitSurvey.js"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>