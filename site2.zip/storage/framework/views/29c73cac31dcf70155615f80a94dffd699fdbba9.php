<?php /* C:\xampp\htdocs\site2\resources\views/pages/offer.blade.php */ ?>
<?php $__env->startSection('title',$offer->location->locationName); ?>
<?php $__env->startSection('content'); ?>
    <div class="row content">
        <div class="col-12 col-lg-6">
            <div style="position: relative" id="modalImageSmall" data-toggle="modal" data-target="#modalImage">
                <img src="<?php echo e(url('/').$offer->picture->src); ?>" class="rounded img-fluid" alt="<?php echo e($offer->picture->alt); ?>">
                <div class="rounded centered">Click to enlarge</div>
            </div>
        </div>
        <div class="col-12 col-lg-6">
            <div class="card">
                <h5 class="card-header"><?php echo e($offer->location->locationName); ?> -<?php echo e($offer->country->countryName); ?></h5>
                <ul class="list-group list-group-flush">
                    <li class="list-group-item">Time of year: <?php echo e($offer->season->seasonName); ?></li>
                    <li class="list-group-item">Price (including hotel and transport): $<?php echo e($offer->price); ?></li>
                    <li class="list-group-item text-justify">
                        Description of the location:<br/>
                        <p style="margin-top: 10px;"><?php echo e($offer->description); ?></p>
                    </li>
                </ul>
            </div>
        </div>
    </div>
    <div class="modal fade" id="modalImage" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-xl" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><?php echo e($offer->location->locationName); ?> -<?php echo e($offer->country->countryName); ?></h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <img data-toggle="modal" data-target="#modalImage" src="<?php echo e(url('/').$offer->picture->src); ?>" class="rounded img-fluid" alt="<?php echo e($offer->picture->alt); ?>">
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(url('/')); ?>/js/offer.js"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>