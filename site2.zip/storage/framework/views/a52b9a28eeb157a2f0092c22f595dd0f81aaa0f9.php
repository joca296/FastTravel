<?php /* C:\xampp\htdocs\site2\resources\views/pages/admin/insert/country.blade.php */ ?>
<?php $__env->startSection('title','Admin - Insert Country'); ?>

<?php $__env->startSection('content'); ?>
    <h1>Insert country:</h1>
    <form action="<?php echo e(url('/')); ?>/admin/insert/country" method="post">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for="country">Country:</label>
            <input type="text" name="country" id="tbCountry" class="form-control">
        </div>
        <div class="form-group">
            <button type="submit" class="btn btn-primary" name="btnInsertCountry">Insert</button>
            <button type="reset" class="btn btn-danger" name="btnReset">Reset</button>
        </div>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>