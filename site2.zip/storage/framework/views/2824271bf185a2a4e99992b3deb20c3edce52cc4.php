<?php /* C:\xampp\htdocs\site2\resources\views/pages/admin/surveyResults.blade.php */ ?>
<?php $__env->startSection('title','Survey Results'); ?>

<?php $__env->startSection('content'); ?>
    <h1>Survey Results</h1>
    <div class="table-responsive-sm">
        <table class="table table-striped table-sm">
            <thead class="thead-dark">
            <th scope="col">#</th>
            <th scope="col">Full name</th>
            <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <th scope="col"><?php echo e($question->question); ?></th>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <th scope="col">Comment</th>
            </thead>
            <tbody>
            <?php $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <th scope="row"><?php echo e($result->idResult); ?></th>
                <td><?php echo e($result->user->firstName." ".$result->user->lastName); ?></td>
                <td><?php echo e($result->answer1->answer); ?></td>
                <td><?php echo e($result->answer2->answer); ?></td>
                <td><?php echo e($result->comment); ?></td>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>