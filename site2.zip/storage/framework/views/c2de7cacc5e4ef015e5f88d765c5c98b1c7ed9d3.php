<?php /* C:\xampp\htdocs\site2\resources\views/layouts/footer.blade.php */ ?>
</body>
</html>