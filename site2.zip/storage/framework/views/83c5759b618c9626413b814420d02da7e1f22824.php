<?php /* C:\xampp\htdocs\site2\resources\views/include/message.blade.php */ ?>
<?php if(isset($message)): ?>
    <div class="col-12">
        <div class="content alert alert-<?php echo e($messageType); ?>" role="alert">
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
            <h4 class="alert-heading"><?php echo e($messageHeading); ?></h4>
            <p><?php echo e($message); ?></p>
            <?php if(isset($showHomeLink)): ?>
                <p>
                    Click <a href="<?php echo e(url('/')); ?>">here</a> to view the home page.
                </p>
            <?php endif; ?>
        </div>
    </div>
<?php endif; ?>