<?php /* C:\xampp\htdocs\site2\resources\views/pages/offers.blade.php */ ?>
<?php $__env->startSection('title','Offers'); ?>
<?php $__env->startSection('content'); ?>
    <nav class="navbar navbar-expand-xl navbar-dark bg-dark">
        <span class="navbar-brand d-xl-none">Search</span>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav1" aria-controls="navbarNav1" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav1">
            <form action="<?php echo e(url('/')); ?>/offers" method="POST" class="form-inline my-2 my-lg-0" id="searchOffers">
                <?php echo csrf_field(); ?>
                <select class="custom-select mr-2" name="country" id="sCountry">
                    <option value="selectCountry">Country...</option>
                    <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($country->idCountry); ?>"><?php echo e($country->countryName); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <select class="custom-select mr-2" name="location" id="sLocation">
                    <option value="selectLocation">Location...</option>
                </select>
                <select class="custom-select mr-2" name="season" id="sSeason">
                    <option value="selectSeason">Season...</option>
                    <?php $__currentLoopData = $seasons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $season): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($season->idSeason); ?>"><?php echo e($season->seasonName); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <input type="number" class="form-control mr-2 col-xl-2" name="minPrice" id="minPrice" placeholder="Minimum price">
                <input type="number" class="form-control mr-2 col-xl-2" name="maxPrice" id="maxPrice" placeholder="Maximum price">
                <select class="custom-select mr-2" name="sort" id="sSort">
                    <option value="sort">Sort...</option>
                    <option value="locationNameASC">Name A-Z</option>
                    <option value="locationNameDESC">Name Z-A</option>
                    <option value="priceASC">Price ascending</option>
                    <option value="priceDESC">Price descending</option>
                </select>
                <button type="submit" class="btn btn-outline-success mr-2" name="btnSearch">Search</button>
            </form>
        </div>
    </nav>
    <div class="row content" id="offers">
    <?php $__currentLoopData = $offers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $offer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-6 col-lg-4">
                <div class="card">
                    <img src="<?php echo e(url('/').$offer->picture->src); ?>" class="card-img-top" alt="<?php echo e($offer->picture->alt); ?>">
                    <div class="card-body">
                        <h4 class="card-title"><?php echo e($offer->location->locationName); ?> - <?php echo e($offer->country->countryName); ?></h4>
                        <h5 class="card-title"><?php echo e($offer->season->seasonName); ?></h5>
                        <p class="card-text text-justify text-truncate"><?php echo e($offer->description); ?></p>
                        <div class="d-flex justify-content-between align-items-center">
                            <a href="<?php echo e(url('/')); ?>/offers/<?php echo e($offer->idOffer); ?>" class="btn btn-outline-dark">More</a>
                            <span class="card-text font-weight-bold">$<?php echo e($offer->price); ?></span>
                        </div>
                    </div>
                </div>
            </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php if(!isset($noPagination)): ?>
            <div class="col-12">
                <?php echo e($offers->links()); ?>

            </div>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(url('/')); ?>/js/locationFilter.js"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>