<?php /* C:\xampp\htdocs\site2\resources\views/include/locations.blade.php */ ?>
<option value="">Location...</option>
<?php $__currentLoopData = $locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $location): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <option value="<?php echo e($location->idLocation); ?>"><?php echo e($location->locationName); ?></option>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>