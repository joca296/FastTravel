<?php /* C:\xampp\htdocs\site2\resources\views/pages/updateEmail.blade.php */ ?>
<?php $__env->startSection('title','Change Email'); ?>
<?php $__env->startSection('content'); ?>
    <div class="row content">
        <div class="col-invisible col-lg-3"></div>
        <div class="col-12 col-lg-6">
            <form action="<?php echo e(url('/')); ?>/user/changeEmail" method="POST">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label for="newEmail">New email address:</label>
                    <input type="text" name="newEmail" class="form-control">
                </div>
                <div class="form-group">
                    <button type="submit" class="btn btn-primary" name="btnUpdate">Update</button>
                    <button type="reset" class="btn btn-danger" name="btnReset">Reset</button>
                    <a href="<?php echo e(url('/')); ?>/user/dashboard" class="btn btn-warning">Return to dashboard</a>
                </div>
            </form>
        </div>
        <div class="col-invisible col-lg-3"></div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>