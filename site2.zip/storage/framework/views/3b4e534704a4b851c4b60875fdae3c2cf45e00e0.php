<?php /* C:\xampp\htdocs\site2\resources\views/pages/dashboard.blade.php */ ?>
<?php $__env->startSection('title','Dashboard'); ?>
<?php $__env->startSection('content'); ?>
    <div class="row content">
        <div class="col-invisible col-lg-3"></div>
        <div class="col-12 col-lg-6">
            <table class="table table-striped table-hover">
                <tr>
                    <th>First name:</th>
                    <td><?php echo e($user->firstName); ?></td>
                </tr>
                <tr>
                    <th>Last name:</th>
                    <td><?php echo e($user->lastName); ?></td>
                </tr>
                <tr>
                    <th>Email address:</th>
                    <td><?php echo e($user->eMail); ?></td>
                </tr>
                <tr>
                    <th>Taken survey:</th>
                    <td><?php echo e($user->survey == 1? "Yes":"No"); ?></td>
                </tr>
            </table>
            <a href="<?php echo e(url('/')); ?>/user/changeEmail" class="btn btn-primary">Change email address</a>
            <a href="<?php echo e(url('/')); ?>/user/changePassword" class="btn btn-primary">Change password</a>
            <a href="<?php echo e(url('/')); ?>/user/delete" class="btn btn-danger">Delete account</a>
        </div>
        <div class="col-invisible col-lg-3"></div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>