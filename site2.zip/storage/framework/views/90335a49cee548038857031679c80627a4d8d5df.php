<?php /* C:\xampp\htdocs\site2\resources\views/include/head.blade.php */ ?>
<!DOCTYPE html>
<html>
<head>
    <title>Fast Travel - <?php echo $__env->yieldContent('title'); ?></title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <meta name="description" content="Cheap and fast holiday booking.">
    <meta name="keywords" content="holiday,travel,tourism">
    <meta name="author" content="Jovan Sekulic">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <link rel="icon" href="<?php echo e(url('/')); ?>/images/icon.ico">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css" integrity="sha384-GJzZqFGwb1QTTN6wy59ffF1BuGJpLSa9DkKMp0DgiMDm4iYMj70gZWKYbI706tWS" crossorigin="anonymous">
    <link rel="stylesheet" href="<?php echo e(url('/')); ?>/css/1.css">
    <link rel="stylesheet" href="<?php echo e(url('/')); ?>/css/sidebar.css">
</head>
<body>