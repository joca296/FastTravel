<?php /* C:\xampp\htdocs\site2\resources\views/layouts/login.blade.php */ ?>
<?php if(Auth::check()): ?>
    <form action="<?php echo e(url('/')); ?>/user/logout" method="POST" class="form-inline my-2 my-lg-0">
        <?php echo csrf_field(); ?>
        <label class="navbar-text mr-2" style="margin-bottom: 0px;"><?php echo e(Auth::user()->firstName); ?>&nbsp;<?php echo e(Auth::user()->lastName); ?></label>
        <button type="submit" class="btn btn-outline-danger mr-2" name="btnLogout">Log Out</button>
    </form>
<?php endif; ?>
<?php if(!Auth::check()): ?>
    <form action="<?php echo e(url('/')); ?>/user/login" method="POST" class="form-inline my-2 my-lg-0">
        <?php echo csrf_field(); ?>
        <input type="text" class="form-control mr-2" placeholder="E-mail Address" name="eMail">
        <input type="password" class="form-control mr-2" placeholder="Password" name="password">
        <button type="submit" class="btn btn-outline-primary mr-2" name="btnLogin">Log In</button>
    </form>
<?php endif; ?>
<?php if(session()->has('loginError')): ?>
    <div class="alert alert-danger alert-dismissible fade show" role="alert" style="margin-bottom: 0px;">
        <span><?php echo e(session()->get('loginError')); ?></span>
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
        <?php session()->forget('loginError');?>
    </div>
<?php endif; ?>