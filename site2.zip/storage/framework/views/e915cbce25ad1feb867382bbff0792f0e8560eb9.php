<?php /* C:\xampp\htdocs\site2\resources\views/pages/admin/slides.blade.php */ ?>
<?php $__env->startSection('title','Admin - Slide List'); ?>

<?php $__env->startSection('content'); ?>
    <h1>Slides</h1>
    <div class="table-responsive-sm">
        <table class="table table-striped table-sm">
            <thead class="thead-dark">
            <th>#</th>
            <th>Caption</th>
            <th>Sub-caption</th>
            <th class="text-center">Action</th>
            </thead>
            <tbody>
            <?php $__currentLoopData = $slides; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slide): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($slide->idSlide); ?></td>
                    <td><?php echo e($slide->caption); ?></td>
                    <td><?php echo e($slide->subCaption); ?></td>
                    <td class="text-center" style="max-width: 80px">
                        <a href="<?php echo e(url('/')); ?>/slides/edit/<?php echo e($slide->idSlide); ?>" class="btn btn-outline-primary">Update</a>
                        <a href="<?php echo e(url('/')); ?>/slides/delete/<?php echo e($slide->idSlide); ?>" class="btn btn-outline-danger">Delete</a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>