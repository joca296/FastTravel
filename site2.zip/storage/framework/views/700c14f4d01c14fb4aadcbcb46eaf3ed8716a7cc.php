<?php /* C:\xampp\htdocs\site2\resources\views/layouts/loginError.blade.php */ ?>
<?php if(isset($loginError)): ?>
    <div class="alert alert-danger alert-dismissible fade show" role="alert" style="margin-bottom: 0px;">
        <span><?php echo e($loginError); ?></span>
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
    </div>
<?php endif; ?>